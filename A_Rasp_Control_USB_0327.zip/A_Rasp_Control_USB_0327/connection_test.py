import cv2
import os
from robomaster import robot
import time

# 저장 디렉토리 설정
save_dir = "C:/admin/yolov5/checker"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# 사진 파일명 카운터 초기화
image_count = len(os.listdir(save_dir))  # 기존 파일 수 기반으로 시작
print(f"현재 저장된 이미지 수: {image_count}")

# RoboMaster 로봇 초기화
rm_robot = robot.Robot()
rm_robot.initialize(conn_type="sta", sn="159CJC400700S2")  # SN은 실제 로봇의 시리얼 넘버로 설정
rm_camera = rm_robot.camera

# 카메라 스트림 시작
rm_camera.start_video_stream(display=False, resolution="720p")

try:
    while True:
        # 카메라에서 프레임 읽기
        frame = rm_camera.read_cv2_image(strategy="newest")
        
        # 프레임 표시
        cv2.imshow("RoboMaster Camera", frame)

        # 키 입력 대기 (1ms)
        key = cv2.waitKey(1) & 0xFF

        # 's' 키를 누르면 사진 저장
        if key == ord('s'):
            image_count += 1
            filename = f"{save_dir}/robot_{image_count:03d}.jpg"  # 예: robot_001.jpg
            cv2.imwrite(filename, frame)
            print(f"이미지 저장됨: {filename}")

        # 'q' 키를 누르면 종료
        elif key == ord('q'):
            print("촬영 종료")
            break

except KeyboardInterrupt:
    print("사용자에 의해 중단됨")

finally:
    # 카메라 스트림 종료 및 로봇 연결 해제
    rm_camera.stop_video_stream()
    rm_robot.close()
    cv2.destroyAllWindows()