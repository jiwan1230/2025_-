from robomaster import robot
from inits import *
import time

# ✅ 1. 로봇 객체 생성 및 Wi-Fi 연결 (sta 모드)
ep_robot = robot.Robot()
ep_robot.initialize(conn_type="sta", sn="159CJC400700ZQ")  # 로봇 SN 변경 필요

# ✅ 2. 샤시(Chassis) 객체 가져오기
ep_chassis = ep_robot.chassis

# ✅ 3. 설정 값 정의
NUMOF_NODE = 1  # 로봇 개수 (단일 로봇 사용)
SENSOR_ANGLES = [0, 90, -90]  # 거리 측정 센서 각도

# ✅ 4. 장애물 회피 및 기타 설정
enableAvoidObstacle = True  # 장애물 회피 활성화
ACHIEVED_CONDITION_DISTANCE = 0.05  # 목표 도달 거리 기준
BLENDING_DISTANCE, BLENDING_SIGMA = 0.05, 0.15
BLENDING_STATE = {
    'emergency': {'d': 0.1, 'sigma': 0.7},
    'warning': {'d': 0.15, 'sigma': 0.6},
    'week_warning': {'d': 0.2, 'sigma': 0.5},
    'detected': {'d': BLENDING_DISTANCE, 'sigma': BLENDING_SIGMA}
}
OBST_DETECT_MARGIN = 10  # 장애물 감지 여유 거리
RUNNING_TIME_LIMIT = 180  # 실행 시간 제한 (초)

# ✅ 현재 로봇 위치 확인
current_x, current_y = 0, 0  # 기본값 (0,0)

try:
    from estimation import Estimation  # 위치 추적 모듈 가져오기
    ESTM = Estimation(NUMOF_NODE, SENSOR_ANGLES)
    pos_matrix = ESTM.get_node_position_matrix()  # 현재 위치 행렬 가져오기

    if pos_matrix is not None and pos_matrix.shape[0] > 0:
        current_x, current_y = pos_matrix[0, 0], pos_matrix[0, 1]  # 첫 번째 로봇의 위치 가져오기
        print(f"📍 현재 위치: ({current_x:.2f}, {current_y:.2f})")
except Exception as e:
    print("⚠️ 현재 위치를 가져오는 데 실패했습니다:", e)

#현재 위치 설정
DST = (current_x + 2, current_y + 2)  # 현재 위치에서 1m 이동하도록 설정

# ✅ 5. 목표 위치 설정

task = ['GoToGoal', (None, DST)]  # 'GoToGoal' 실행

# ✅ 6. 로봇 이동 테스트
print(f"🚀 목표 {DST}로 이동 시작...")
start_time = time.time()

# 목표 지점까지 전진
ep_chassis.move(x=DST[0], y=DST[1], z=0, xy_speed=0.4).wait_for_completed()

# 실행 제한 시간 초과 시 종료
while time.time() - start_time < RUNNING_TIME_LIMIT:
    print("⏳ 이동 중...")
    time.sleep(5)  # 5초마다 상태 확인

print("✅ 목표 지점 도착 완료!")

# ✅ 7. 로봇 종료
ep_robot.close()
