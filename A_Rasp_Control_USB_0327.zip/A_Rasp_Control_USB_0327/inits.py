# from Library_files.robomaster_inits import get_online_robot_info, mylog

from Library_files.estimation import Estimation
# from Library_files.motion_track import create_motion_tracker, tracking_position

from Library_files.myrobomaster import MyRobomaster
from Library_files.Lowlevel.low_level_control_methods import LowLevelControlMethods as llcMethod
from Library_files.Lowlevel.low_level_control_robomaster import LowLevelControlRobomaster as llcRobo

from Library_files.middle_level import MiddleLevelControl
from Library_files.high_level import HighLevelControl

import time
import numpy as np
import threading
from threading import Thread
import logging

from timeit import default_timer as timer

#------ Broadcast ------
import socket
import pickle
from datetime import datetime


import sys
from datetime import datetime as dt
g_debug_msg = []
sys._getframe(0).f_code.co_name

def enable_flag_tracking():
    global g_flag_tracking
    g_flag_tracking = True

def disable_flag_tracking():
    global g_flag_tracking
    g_flag_tracking = False

def wait_flag_tracking_on():
    global g_flag_tracking
    while not g_flag_tracking: pass

# -------------- estimation --------------
def _exist_tracking_information():
    global g_tracking_info
    if None in g_tracking_info.values():
        return False
    else:
        return True

def _exist_sensor_data():
    global g_robots
    global g_distance_matrix
    if None in g_robots.values(): return False
    
    for vector in g_distance_matrix:
        try:
            if np.any(vector==-1):
                return False
        except Exception as e:
            print(e)
            return False
    return True

def wait_until_tracking_information_init():
    while not _exist_tracking_information(): pass

def wait_until_sensor_data_init():
    while not _exist_sensor_data(): pass

# -------------- Low level control --------------
def _exist_task_vector():
    global g_flag_task_vector
    return g_flag_task_vector
def wait_until_task_vectors_init():
    while not _exist_task_vector(): pass

# -------------- Middle level control --------------
def _exist_estimation_data():
    global g_pos_matrix
    global g_prox_vm

    if np.any(g_pos_matrix==-1):
        return False
    if np.any(g_prox_vm==-1) :
        return False

    return True

def init_task_vector():
    global g_flag_task_vector
    g_flag_task_vector = 1

def wait_until_estimation_data_init():
    while not _exist_estimation_data(): pass

def wait_purpose_from_high_level():
    global g_objective
    while g_objective == None: pass

# -------------- Main control --------------
def enable_flag_program_run():
    global g_flag_program_run
    g_flag_program_run = True

def disable_flag_program_run():
    global g_flag_program_run
    g_flag_program_run = False

def wait_flag_program_run_on():
    global g_flag_program_run
    while not g_flag_program_run: pass

def loop_receive_from_PC_broadcast():
    global g_flag_program_run
    global np_pos
    global np_ori
    global my_node_idx
    #나는 0번 index!

    RECEIVE_IP = ''
    RECEIVE_PORT = 8888

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((RECEIVE_IP, RECEIVE_PORT))

    print("[Receiver] 브로드캐스트 수신 대기 중...")

    while not g_flag_program_run: time.sleep(0.01)
    while g_flag_program_run:
        try:
            data, addr = sock.recvfrom(4096)
            unpacked = pickle.loads(data)
            
            if unpacked["node_idx"] == my_node_idx:
                np_pos = unpacked["np_pos"]
                np_ori = unpacked["np_ori"]

                print(f"[Receiver] From {addr} |{my_node_idx} \n np_pos : {np_pos} | np_ori : {np_ori}]")
            else:
                print(f"[Receiver] Not mine")

        except Exception as e:
            print(f"[Receiver] 수신 오류: {e}")

    sock.close()
    print(f"[Receiver] NODE {my_node_idx} 종료됨")

def loop_estimation_and_Broad_to_Rasp():
    global ESTM

    global my_node_idx
    global np_pos
    global np_ori
    
    BROADCAST_IP = '255.255.255.255'
    PORT = 7777
    INTERVAL = 0.5  # 0.5초마다 전송
    who = 1
    # g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_sensor_data_init'])
    # wait_until_sensor_data_init()
    # g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: free_wait_until_sensor_data_init'])

    sock2 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock2.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    print(f"[MY Estimation and Broadcast] 초기화 완료. 대기 중...")
    
    while not g_flag_program_run: pass

    print(f"[MY Estimation and Broadcast] 시작됨!")
    while g_flag_program_run:
        my_g_pos_matrix, my_np_theta = ESTM.estimation_my_pos_theta(np_pos, np_ori)
        ESTM.make_full_matrix(my_g_pos_matrix,who)
        try:
            data = {
                "g_pos": my_g_pos_matrix,
                "theta": my_np_theta
            }
            sock2.sendto(pickle.dumps(data), (BROADCAST_IP, PORT))
            print(f"[{my_node_idx} my_g_pos_matrix : {my_g_pos_matrix} | my_np_theta : {my_np_theta}]")
        except Exception as e:
            print(f"[Broadcast] 전송 오류: {e}")
        time.sleep(INTERVAL)

    sock2.close()    
    print('[MY Estimation and Broadcast End]')

def loop_receive_from_Rasp_broadcast():
    global ESTM

    global g_flag_program_run
    #나는 0번 index!

    who = 2
    RECEIVE_IP = ''
    RECEIVE_PORT = 7777

    sock3 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock3.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    sock3.bind((RECEIVE_IP, RECEIVE_PORT))

    print("[Receiver from Rasp] 브로드캐스트 수신 대기 중...")

    while not g_flag_program_run: time.sleep(0.01)
    while g_flag_program_run:
        try:
            data, addr = sock3.recvfrom(4096)
            unpacked = pickle.loads(data)
            
            temp_g_pos = unpacked["g_pos"]
            temp_theta = unpacked["theta"]

            print(f"[Receiver from other Rasp] g_pos : {temp_g_pos} | theta : {temp_theta}]")
            ESTM.make_full_matrix(temp_g_pos, who)
        except Exception as e:
            print(f"[Receiver from Rasp] 수신 오류: {e}")

    sock3.close()
    print(f"[Receiver from other Rasp] NODE 종료됨")

def loop_estimation_theta():
    global ESTM
    # global g_tracking_info
    global g_distance_matrix
    global full_g_pos_matrix
    global g_pos_matrix
    global g_prox_vm
    global g_prox_uvm_fw
    global np_pos
    global np_ori
    
    # g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_tracking_information_init'])
    # wait_until_tracking_information_init()
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_sensor_data_init'])
    wait_until_sensor_data_init()
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: free_wait_until_sensor_data_init'])

    while not g_flag_program_run: pass
    while g_flag_program_run:
        g_pos_matrix, np_theta = ESTM.extract_pose_and_theta_as_numpy(full_g_pos_matrix)
        g_prox_vm, g_prox_uvm_fw = ESTM.estimation_routine2(np_theta, g_distance_matrix)
    print('[Estimation End]')

    #!-------------------------------------------------------------------------------------------
def loop_my_estimation():
    global ESTM
    # global g_tracking_info
    global g_distance_matrix

    global full_g_pos_matrix
    global g_prox_vm
    global g_prox_uvm_fw
    global np_pos
    global np_ori
    
    # g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_tracking_information_init'])
    # wait_until_tracking_information_init()
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_sensor_data_init'])
    wait_until_sensor_data_init()
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: free_wait_until_sensor_data_init'])

    while not g_flag_program_run: pass
    while g_flag_program_run:
        g_pos_matrix, g_prox_vm, g_prox_uvm_fw = ESTM.estimation_routine2(np_pos, np_ori, g_distance_matrix)
    print('[Estimation End]')


#
def loop_estimation():
    global ESTM
    global g_tracking_info
    global g_distance_matrix

    global g_pos_matrix
    global g_prox_vm
    global g_prox_uvm_fw

    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_tracking_information_init'])
    wait_until_tracking_information_init()
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_sensor_data_init'])
    wait_until_sensor_data_init()
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: free_wait_until_sensor_data_init'])

    while not g_flag_program_run: pass
    while g_flag_program_run:
        g_pos_matrix, g_prox_vm, g_prox_uvm_fw = ESTM.estimation_routine(g_tracking_info, g_distance_matrix)
    print('[Estimation End]')

def loop_high_level_control(HLC):
    global g_flag_program_run
    global g_objective

    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_flag_program_run_on'])
    wait_flag_program_run_on()
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: free_wait_flag_program_run_on'])

    HLC_start_time = timer()
    HLC_elapsed_time = timer() - HLC_start_time
    while g_flag_program_run and not HLC._is_over_running_time(HLC_elapsed_time):
        g_objective = HLC.high_level_control_routine()
        HLC_elapsed_time = timer() - HLC_start_time

def loop_middle_level_control(MLC):
    global g_flag_program_run
    global g_objective
    global g_task_vector_matrix
    
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_robot_data_init'])
    wait_until_estimation_data_init() # 로봇 위치 데이터가 준비될 때까지 대기
    g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: free_wait_until_robot_data_init'])
    
    while g_flag_program_run:
        g_task_vector_matrix = MLC.middle_level_control_routine(g_objective)

def loop_low_level_control(LLC, enableAvoidObstacle):
    global g_flag_program_run

    global g_task_vector_matrix
    global g_distance_matrix
    global g_pos_matrix
    global g_prox_uvm_fw

    robot = LLC.rob

    th_gimbal = LLC.init_gimbal()
    LLC.init_sensor(g_distance_matrix) #초음파 세서를 구독하여 장애물 거리 정보를 받음

    while np.any(g_task_vector_matrix==0): pass # 중간 레벨 제어에서 테스크 벡터가 설정될 때 까지 기다린다
    #테스크 벡터 설정은 loop_middle_level_control 여기에서
    #* ----- 3. wait for main flag on ----- 
    while not g_flag_program_run: pass
    start = timer()
    #* ----- 4. while main flag on, just sleep -> routines are running by thread -----
    while g_flag_program_run:
        LLC.send_to_node(g_task_vector_matrix, g_pos_matrix, g_prox_uvm_fw, enableAvoidObstacle)
    end = timer() - start
            
    #* ----- 5. terminate thread ----- 
    robot._chassis.unsub_attitude()

    if robot.model == 's1':
        th_gimbal.join()
    
    robot.close()  
    print(f'[NODE{robot.node_idx}] Closed / recv_rate:{LLC.recv_cnt/end} send_rate:{LLC.send_cnt/end}')    

def example_running(task, NODE_IDK, SENSOR_ANGLES, ACHIEVED_CONDITION_DISTANCE, BLENDING_STATE, OBST_DETECT_MARGIN, RUNNING_TIME_LIMIT, enableAvoidObstacle, ROTATION):
    global ESTM
    
    NUMOF_NODE = 1
    NUMOF_SENSOR = len(SENSOR_ANGLES)

    #*-------- 1. receive broadcast from PC thread enable, but no start by flag --------
    # PC로부터 브로드캐스트 수신 쓰레드 실행
    receiver_thread = threading.Thread(target= loop_receive_from_PC_broadcast, daemon=True)
    receiver_thread.start()

    #*-------- 1.1 estimation and broadcast Rasp to Rasp thread enable, but no start by flag --------
    # 간단 estimation 및 broadcast
    broad_thread = threading.Thread(target= loop_estimation_and_Broad_to_Rasp, daemon=True)
    broad_thread.start()

    #*-------- 1.2 recieve rasp_pos_theta and make Full matrix, but no start by flag --------
    # 간단 estimation 및 broadcast
    receive_and_make_thread = threading.Thread(target= loop_receive_from_Rasp_broadcast, daemon=True)
    receive_and_make_thread.start()
    
    
    #* ------- 2. estimating thread enable, but no start by flag -------
    ESTM = Estimation(NUMOF_NODE, SENSOR_ANGLES)
    estimating_thread = Thread(target=loop_my_estimation, args=(), daemon=True)
    estimating_thread.start()

    #* ------- 3.1. Node Init -------
    try:
        robot = MyRobomaster(NODE_IDK)
        robot.MIN_RPM = 200
        robot.MAX_RPM = 500
        robot.MIN_ROTATION_RPM = 100

        robot._chassis =  robot.chassis
        g_robots[NODE_IDK] = robot
        
    except Exception as e:
        print(f'[NODE{NODE_IDK}] INIT ERROR')
        raise Exception(e)

    #* ------- 3.2. low level control thread start -------
    low_level_control_thread_list = []
    for node_idx, rob in g_robots.items():
        if node_idx == 4:
            LLC = llcRobo(ESTM, rob, NUMOF_SENSOR, ACHIEVED_CONDITION_DISTANCE, BLENDING_STATE, OBST_DETECT_MARGIN, leader_node=True)
        else:
            LLC = llcRobo(ESTM, rob, NUMOF_SENSOR, ACHIEVED_CONDITION_DISTANCE, BLENDING_STATE, OBST_DETECT_MARGIN)

        llc_thread = Thread(target=loop_low_level_control, args=(LLC,enableAvoidObstacle), daemon=True)
        llc_thread.start()
        low_level_control_thread_list.append(llc_thread)

    #* ------- 4. Middle level control -------
    mlc_class = MiddleLevelControl(ESTM, g_robots, ACHIEVED_CONDITION_DISTANCE, ROTATION)
    mlc_thread = Thread(target=loop_middle_level_control, args=(mlc_class,), daemon=True)
    mlc_thread.start()

    #* ------- 5. high level control -------
    g_objective = task
    hlc_class = HighLevelControl(g_objective, RUNNING_TIME_LIMIT)
    hlc_thread = Thread(target=loop_high_level_control, args=(hlc_class,), daemon=True)
    hlc_thread.start()

    #* ------- program start flag enable -------
    enable_flag_program_run()

    time.sleep(RUNNING_TIME_LIMIT)

    #* ------- program start flag enable -------
    disable_flag_program_run()

    #* ------- terminate all thread -------
    # Motion_tracking_thread.join()
    receiver_thread.join()
    estimating_thread.join()
    broad_thread.join()
    for llcth in low_level_control_thread_list:
        llcth.join()
    mlc_thread.join()
    hlc_thread.join()


def init_(NUMOF_NODE, NODE_IDX, SENSOR_ANGLES):
    global g_flag_program_run
    global g_tracking_info
    global g_distance_matrix
    global g_pos_matrix
    global g_prox_vm
    global g_prox_uvm_fw
    global g_task_vector_matrix
    global g_robots
    global g_objective
    global np_pos
    global np_ori
    global pos_matrix_lock  # 전역 락 선언
    global my_node_idx
    global full_g_pos_matrix

    my_node_idx = NODE_IDX

    #mylog.setLevel(logging.ERROR)
    # robots_info = get_online_robot_info(3)
    # # numFindNode = len(robots_info.keys())
    # numFindNode = 1


    # print(f'#Of Nodes{NUMOF_NODE}\n#Of find nodes:{numFindNode}\n{robots_info}')
    # if NUMOF_NODE != numFindNode:
    #     raise Exception('Node count mismatch')

    NODE_IDX_LIST = [i for i in range(NUMOF_NODE)] if NUMOF_NODE else [0]
    NUMOF_SENSOR = len(SENSOR_ANGLES)
    
    g_flag_program_run = False
    # g_tracking_info = {node_idx:None for node_idx in NODE_IDX_LIST}
    g_distance_matrix = -1*np.ones((NUMOF_NODE, NUMOF_SENSOR))
    g_pos_matrix = -1*np.ones((NUMOF_NODE, 3))
    g_prox_vm = -1*np.ones((NUMOF_NODE, NUMOF_SENSOR))
    g_prox_uvm_fw = -1*np.ones((NUMOF_NODE, NUMOF_SENSOR))
    g_robots = {node_idx:None for node_idx in NODE_IDX_LIST}

    g_task_vector_matrix = np.zeros((NUMOF_NODE, 2))
    pos_matrix_lock = threading.Lock()  # 전역 락 객체 생성
    # full_g_pos_matrix 초기화
    full_g_pos_matrix = {0: {'pos': [-1, -1, -1], 'timestamp': datetime.now()}}                        
    
    np_pos = -1*np.ones((NUMOF_NODE, 3))
    np_ori = -1*np.ones((NUMOF_NODE, 3))
