import pygame
import random

# 초기화
pygame.init()

# 화면 설정
WIDTH = 800
HEIGHT = 600
BLOCK_SIZE = 30
GRID_WIDTH = 10
GRID_HEIGHT = 20
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tetris by Grok")

# 색상 정의
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
CYAN = (0, 255, 255)
YELLOW = (255, 255, 0)
MAGENTA = (255, 0, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
ORANGE = (255, 165, 0)

# 테트로미노 모양 정의
SHAPES = [
    [[1, 1, 1, 1]],  # I
    [[1, 1], [1, 1]],  # O
    [[1, 1, 1], [0, 1, 0]],  # T
    [[1, 1, 1], [1, 0, 0]],  # L
    [[1, 1, 1], [0, 0, 1]],  # J
    [[1, 1, 0], [0, 1, 1]],  # S
    [[0, 1, 1], [1, 1, 0]]   # Z
]

COLORS = [CYAN, YELLOW, MAGENTA, ORANGE, BLUE, GREEN, RED]

# 게임 변수
grid = [[0 for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]
current_piece = None
current_pos = [0, 0]
score = 0
game_over = False
clock = pygame.time.Clock()

def new_piece():
    global current_piece, current_pos
    piece_idx = random.randint(0, len(SHAPES) - 1)
    current_piece = SHAPES[piece_idx]
    current_pos = [0, GRID_WIDTH // 2 - len(current_piece[0]) // 2]

def rotate_piece():
    global current_piece
    current_piece = list(zip(*current_piece[::-1]))
    if check_collision(0, 0):
        current_piece = list(zip(*current_piece))[::-1]  # 회전 취소

def check_collision(dx, dy):
    for y, row in enumerate(current_piece):
        for x, val in enumerate(row):
            if val:
                new_x = current_pos[1] + x + dx
                new_y = current_pos[0] + y + dy
                if (new_x < 0 or new_x >= GRID_WIDTH or
                    new_y >= GRID_HEIGHT or
                    (new_y >= 0 and grid[new_y][new_x])):
                    return True
    return False

def merge_piece():
    for y, row in enumerate(current_piece):
        for x, val in enumerate(row):
            if val:
                grid[current_pos[0] + y][current_pos[1] + x] = COLORS[SHAPES.index(current_piece)] + (1,)

def remove_lines():
    global score, grid
    lines = 0
    new_grid = [row for row in grid if any(cell == 0 for cell in row)]
    lines = GRID_HEIGHT - len(new_grid)
    score += lines * 100
    grid = [[0 for _ in range(GRID_WIDTH)] for _ in range(lines)] + new_grid

def draw_grid():
    for y, row in enumerate(grid):
        for x, val in enumerate(row):
            if val:
                pygame.draw.rect(screen, val[:-1],
                               (x * BLOCK_SIZE + (WIDTH - GRID_WIDTH * BLOCK_SIZE) // 2,
                                y * BLOCK_SIZE, BLOCK_SIZE - 1, BLOCK_SIZE - 1))

def draw_piece():
    for y, row in enumerate(current_piece):
        for x, val in enumerate(row):
            if val:
                pygame.draw.rect(screen, COLORS[SHAPES.index(current_piece)],
                               ((current_pos[1] + x) * BLOCK_SIZE + (WIDTH - GRID_WIDTH * BLOCK_SIZE) // 2,
                                (current_pos[0] + y) * BLOCK_SIZE, BLOCK_SIZE - 1, BLOCK_SIZE - 1))

# 게임 루프
new_piece()
running = True
fall_time = 0
fall_speed = 50  # 프레임 단위

while running:
    fall_time += 1
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and not game_over:
            if event.key == pygame.K_LEFT:
                if not check_collision(-1, 0):
                    current_pos[1] -= 1
            elif event.key == pygame.K_RIGHT:
                if not check_collision(1, 0):
                    current_pos[1] += 1
            elif event.key == pygame.K_DOWN:
                if not check_collision(0, 1):
                    current_pos[0] += 1
            elif event.key == pygame.K_UP:
                rotate_piece()

    if fall_time >= fall_speed and not game_over:
        fall_time = 0
        if not check_collision(0, 1):
            current_pos[0] += 1
        else:
            merge_piece()
            remove_lines()
            new_piece()
            if check_collision(0, 0):
                game_over = True

    # 그리기
    draw_grid()
    if not game_over:
        draw_piece()

    # 점수 표시
    font = pygame.font.Font(None, 36)
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))

    if game_over:
        game_over_text = font.render("Game Over!", True, WHITE)
        screen.blit(game_over_text, (WIDTH // 2 - 70, HEIGHT // 2))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()