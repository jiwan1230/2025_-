import numpy as np
from numpy import exp as nexp
import time
from timeit import default_timer as timer
from math import *
from datetime import datetime, timedelta

#* -------------- Estimation Part  --------------
class Estimation():
    def __init__(self, NUMOF_NODES:int, SENSOR_ANGLES:list):
        self.NUMOF_NODES = NUMOF_NODES
        self.SENSOR_ANGLES = np.array(SENSOR_ANGLES)
        self.NUMOF_SENSORS = len(SENSOR_ANGLES)

        self.node_position_matrix = None
        self.node_distance_matrix = None

        self.vector_obst = None
        self.prox_vector_matrix = None # prox_dist_vector_matrix

        self.vector_fw = None
        self.prox_vector_fw_matrix = None

        self.vector_op = None
        self.prox_vector_op_matrix = None

        self.MAX_DETECT_RANGE = 10 # meter
        self.MIN_DETECT_RANGE = 0.01 # meter

        self.ESTM_THREAD_SLEEP_TIME : float = 0.02

    def get_node_distance_matrix(self):
        return self.node_distance_matrix
    def get_node_position_matrix(self):
        return self.node_position_matrix
    def get_prox_v_fw(self):
        global g_prox_uvm_fw
        return g_prox_uvm_fw[self.node_idx,:]
    
    def get_node_pos(self, node_idx):
        x, y, theta = self.node_position_matrix[node_idx,:]
        return x, y, theta

    def get_node_obstacle_vector_matrix(self, node_idx):
        return self.prox_vector_matrix[node_idx,:].reshape(2,3)
    def get_node_follow_wall_vector_matrix(self, node_idx):
        return self.prox_vector_fw_matrix[node_idx,:].reshape(2,3)
    def get_node_obst_opposite_vector_matrix(self, node_idx):
        return self.prox_vector_op_matrix[node_idx,:].reshape(2,3)

    def get_node_obstacle_vector_comp(self, node_idx):
        return self.vector_obst[node_idx,:]#.reshape(2,1)
    def get_node_follow_wall_vector_comp(self, node_idx):
        return self.vector_fw[node_idx,:]#.reshape(2,1)
    def get_node_obst_opposite_vector_comp(self, node_idx):
        return self.vector_op[node_idx,:]#.reshape(2,1)
    #* ################################################

    @staticmethod
    def dict2numpy(g_tracking_info):
        dic = g_tracking_info
        num = len(dic.keys())
        np_pos = np.zeros((num, 3)) # #of position information is 3
        np_ori = np.zeros((num, 4)) # #of orientation information is 4

        for k, val in dic.items():
            np_pos[k:] = np.array(val.position).reshape(1,3) # shape (1,3)
            np_ori[k:] = np.array(val.orientation).reshape(1,4) # shape (1,4)
        
        return np_pos, np_ori

    def update_global_pose_matrix(self, np_pos, np_ori):
        # read position information of each rigid body, in mm unit
        # (x,y,z) : x, -y, z position in mm unit -> np_pos[:, :-1] -> (n,2):just deal with (x,y)
        np_coordinates =  1000 * np_pos[:, :-1] # shape(n,2)
        n = np_coordinates.shape[0]

        # shape(n,)
        np_theta = np.arctan2(+2.0 * (np_ori[:,3] * np_ori[:,2] + np_ori[:,0] * np_ori[:,1]), +1.0 - 2.0 * (np_ori[:,1] * np_ori[:,1] + np_ori[:,2] * np_ori[:,2]))
        np_theta = np_theta.reshape(n,1) # shape(n,) -> shape(n,1)
        
        # global var update
        g_pos_matrix = np.concatenate((np_coordinates,np_theta),axis=1)
        self.node_position_matrix  = g_pos_matrix
        return g_pos_matrix, np_theta
    #! ----------- 추가 사항 ----------
    def make_full_matrix(self, temp_g_pos, who):
        # 임계값 설정
        DISTANCE_THRESHOLD = 50  # 새로운 로봇으로 간주하는 거리 임계값 (mm)
        TIME_THRESHOLD = 5       # 데이터 유효 시간 (초)

        global full_g_pos_matrix
        current_time = datetime.now()

        if who == 1:
            # 내 정보일 경우 (0번 인덱스와 비교)
            if 0 in full_g_pos_matrix:
                existing_pos = np.array(full_g_pos_matrix[0]['pos'][:2])
                new_pos = np.array(temp_g_pos[:2])
                distance = np.linalg.norm(existing_pos - new_pos)
                # 거리 상관없이 항상 업데이트
                full_g_pos_matrix[0]['pos'] = temp_g_pos
                full_g_pos_matrix[0]['timestamp'] = current_time
                print(f"[Update] 내 정보(0번) 업데이트: {temp_g_pos}, 거리 차이: {distance:.2f}")
            else:
                # 0번이 없으면 새로 추가
                full_g_pos_matrix[0] = {'pos': temp_g_pos, 'timestamp': current_time}
                print(f"[Add] 내 정보(0번) 최초 추가: {temp_g_pos}")
        else:
            # 다른 로봇 정보일 경우 (0번 제외하고 비교)
            min_distance = float('inf')
            closest_idx = None
            new_pos = np.array(temp_g_pos[:2])

            for idx, data in full_g_pos_matrix.items():
                if idx == 0:  # 0번은 건너뜀
                    continue
                existing_pos = np.array(data['pos'][:2])
                distance = np.linalg.norm(existing_pos - new_pos)
                if distance < min_distance:
                    min_distance = distance
                    closest_idx = idx

            # 거리 기준으로 업데이트 또는 추가
            if min_distance <= DISTANCE_THRESHOLD and closest_idx is not None:
                full_g_pos_matrix[closest_idx]['pos'] = temp_g_pos
                full_g_pos_matrix[closest_idx]['timestamp'] = current_time
                print(f"[Update] 로봇 {closest_idx} 위치 업데이트: {temp_g_pos}")
            else:
                new_idx = max(full_g_pos_matrix.keys(), default=-1) + 1
                full_g_pos_matrix[new_idx] = {'pos': temp_g_pos, 'timestamp': current_time}
                print(f"[Add] 새로운 로봇 {new_idx} 추가: {temp_g_pos}")

        # 오래된 데이터 제거 (0번 제외)
        to_remove = []
        for idx, data in full_g_pos_matrix.items():
            if idx != 0 and (current_time - data['timestamp']).total_seconds() > TIME_THRESHOLD:
                to_remove.append(idx)
        for idx in to_remove:
            del full_g_pos_matrix[idx]
            print(f"[Remove] 로봇 {idx} 제거: 업데이트 없음")

        # 딕셔너리 상태로 유지
        # return full_g_pos_matrix
        
    #! ------------------------------------

    def update_prox_distance_matrix(self, sensor_raw_data) -> None:
        # global g_distance_matrix
        distance_matrix = np.round(sensor_raw_data / 1000, 2) # (n,3)

        if self.NUMOF_SENSORS < distance_matrix[:,:].shape[1]:
            distance_matrix = distance_matrix[:,:self.NUMOF_SENSORS]

        # g_distance_matrix = distance_matrix
        self.node_distance_matrix = distance_matrix
    
    def get_vector_matrix(self, mat_x, mat_y):
        N = self.NUMOF_NODES
        M = self.NUMOF_SENSORS

        mat = np.zeros((N, 2*M))
        mat[:,:M] = mat_x
        mat[:,M:] = mat_y
        return mat

    def decompose_real_imag(self, vector_comp): # vector_comp : (N,M)
        M = self.NUMOF_SENSORS
        np_real = np.round(np.real(vector_comp), M) # (N,M)
        np_imag = np.round(np.imag(vector_comp), M) # (N,M)
        return (np_real, np_imag)
    
    # No Use ---------------------------------
    def update_prox_follow_wall_vector_matrix(self, np_d, vector_comp):
        d_w = self.get_avoid_vector_weight_param(np_d)
        self.vector_fw = vector_comp * (d_w * nexp(1j*(pi/2)))
        self.prox_vector_fw_matrix = self.get_vector_matrix(*self.decompose_real_imag(self.vector_fw))
    def update_prox_opposite_vector_matrix(self, np_d, vector_comp):
        d_w = self.get_avoid_vector_weight_param(np_d)
        self.vector_op = vector_comp * (d_w * nexp(1j*(pi)))
        self.prox_vector_op_matrix = self.get_vector_matrix(*self.decompose_real_imag(self.vector_op))
    # No Use ---------------------------------

    def update_prox_vector_matrixes(self, np_heading):
        N = self.NUMOF_NODES
        M = self.NUMOF_SENSORS
        j = 1j

        np_theta = np_heading
        np_sp = self.SENSOR_ANGLES # sp = np.array([0, 45, -45])
        np_d = self.node_distance_matrix # np.array([0, 1, 0])
        np_phase = np.radians(np_sp) # (1,3)

        # np_phase(1,M)+np_theta(1,N) -> (N,M)
        vector_comp = nexp(j*(np_phase+np_theta)).reshape(N,M) # (N,M)
        vector_comp = np.round(vector_comp,4)

        g_prox_vm = np_d * vector_comp
        g_prox_uvm_fw = vector_comp * nexp(j*radians(-90))
        self.vector_obst = g_prox_vm
        self.prox_vector_matrix = g_prox_vm

        return g_prox_vm, g_prox_uvm_fw
        
    def estimation_routine(self, g_tracking_info, g_distance_matrix):
        """
        - By processing the tracking info obtained through the Motion Tracking-Motive Program
            - 1.Create global position vector matrix information and update it to g_pos_matrix.
            - g_pos_matrix: (Nx3) -sized matrix, column represents x, y theta information.

        - By processing the distance info obtained through the IR sensor
            - 2.Proximity vector matrix is created and updated to g_prox_vm.
            - g_prox_vm: (NxM) represented in (x,y) coordinates in the global coordinate system the distance to the obstacle detected by each of the (NxM) size matrix, N nodes, and M sensors.
        """
        #! g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_tracking_information_init'])
        # Motion tracking operates and waits until tracking information is initiated
        #! wait_until_tracking_information_init()
        #! g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_sensor_data_init'])

        # Wait until low level control is activated and sensed distance information is initiated
        #! wait_until_sensor_data_init()
        # g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: free_wait_until_sensor_data_init'])
        
        #! while g_flag_program_run:
        estimating_start_time =  timer()
        
        #* 1. ------- global position estimation -------
        #* get global position vector and heading
        np_pos, np_ori = self.dict2numpy(g_tracking_info)
        #* update global position vector matrix : g_pos_matrix
        g_pos_matrix, np_theta = self.update_global_pose_matrix(np_pos, np_ori)

        #* 2. ------- proximity vector matrix estimation -------
        #* update proximity vector matrix : g_prox_vm
        self.update_prox_distance_matrix(g_distance_matrix)
        g_prox_vm, g_prox_uvm_fw = self.update_prox_vector_matrixes(np_theta)

        estimating_elapsed_time = timer() - estimating_start_time
        #* add intensional sleep time for time-regular update
        #* estimating_elapsed_time: code running time
        #* if estimating_elapsed_time > 0.02 --> no sleep time
        #* else sleep (0.02 - estimating_elapsed_time)
        time.sleep(self.ESTM_THREAD_SLEEP_TIME - estimating_elapsed_time if estimating_elapsed_time < self.ESTM_THREAD_SLEEP_TIME else 0)

        return g_pos_matrix, g_prox_vm, g_prox_uvm_fw
    
    def estimation_my_pos_theta(self, np_pos, np_ori):
        my_g_pos_matrix, my_np_theta = self.update_global_pose_matrix(np_pos, np_ori)
        return my_g_pos_matrix, my_np_theta
    
    def extract_pose_and_theta_as_numpy(self,full_g_pos_matrix):
        """
        full_g_pos_matrix에서 theta 값들만 모은 np_theta와 g_pos_matrix를 NumPy 배열로 생성.
        
        Returns:
            g_pos_matrix (np.ndarray): shape (N, 3)의 배열
            np_theta (np.ndarray): shape (N,)의 배열
        """
        if not full_g_pos_matrix:
            return np.array([]), np.array([])

        # 리스트로 먼저 수집
        g_pos_matrix_list = []
        np_theta_list = []

        for idx in sorted(full_g_pos_matrix.keys()):
            pos_data = full_g_pos_matrix[idx]['pos']
            g_pos_matrix_list.append(pos_data)
            np_theta_list.append(pos_data[2])

        # NumPy 배열로 변환
        g_pos_matrix = np.array(g_pos_matrix_list)  # (N, 3)
        np_theta = np.array(np_theta_list)          # (N,)

        return g_pos_matrix, np_theta
    
    #!--------------------------------------------------------------------




    def estimation_routine2(self, np_theta, g_distance_matrix):
            """
            - By processing the tracking info obtained through the Motion Tracking-Motive Program
                - 1.Create global position vector matrix information and update it to g_pos_matrix.
                - g_pos_matrix: (Nx3) -sized matrix, column represents x, y theta information.

            - By processing the distance info obtained through the IR sensor
                - 2.Proximity vector matrix is created and updated to g_prox_vm.
                - g_prox_vm: (NxM) represented in (x,y) coordinates in the global coordinate system the distance to the obstacle detected by each of the (NxM) size matrix, N nodes, and M sensors.
            """
            #! g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_tracking_information_init'])
            # Motion tracking operates and waits until tracking information is initiated
            #! wait_until_tracking_information_init()
            #! g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: wait_until_sensor_data_init'])

            # Wait until low level control is activated and sensed distance information is initiated
            #! wait_until_sensor_data_init()
            # g_debug_msg.append([dt.now(), f'[{sys._getframe(0).f_code.co_name}]: free_wait_until_sensor_data_init'])
            
            #! while g_flag_program_run:
            estimating_start_time =  timer()
            
            # #* 1. ------- global position estimation -------
            # #* get global position vector and heading
            # np_pos, np_ori = self.dict2numpy(g_tracking_info)
            #* update global position vector matrix : g_pos_matrix
            # g_pos_matrix, np_theta = self.update_global_pose_matrix(np_pos, np_ori)

            #! 여기서 한번 끊고 g_pos_matrix와 np_theta 값을 Broadcast해야함.
            #! 그리고 받아온 값들로 완전한 g_pos_matrix 와 np_theta 를 구성하고 밑에 코드 실행.

            #* 2. ------- proximity vector matrix estimation -------
            #* update proximity vector matrix : g_prox_vm
            self.update_prox_distance_matrix(g_distance_matrix)
            g_prox_vm, g_prox_uvm_fw = self.update_prox_vector_matrixes(np_theta)

            estimating_elapsed_time = timer() - estimating_start_time
            #* add intensional sleep time for time-regular update
            #* estimating_elapsed_time: code running time
            #* if estimating_elapsed_time > 0.02 --> no sleep time
            #* else sleep (0.02 - estimating_elapsed_time)
            time.sleep(self.ESTM_THREAD_SLEEP_TIME - estimating_elapsed_time if estimating_elapsed_time < self.ESTM_THREAD_SLEEP_TIME else 0)

            return g_prox_vm, g_prox_uvm_fw


#* -------------- Estimation Part  --------------